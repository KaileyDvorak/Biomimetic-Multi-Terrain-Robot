"""
sphere_fold_check.py

First-order geometry sanity check: CAN your leg's link lengths
plausibly fold into a spherical wedge of a given sphere size?

This is deliberately a rough, back-of-envelope tool -- the real
answer depends on the specific fold/hinge mechanism you design in
CAD, which doesn't exist yet. What this DOES tell you reliably:
whether your current link lengths are in a plausible ballpark for
your target sphere size, or way off, before you invest CAD time.

Key geometric fact used here: for a hemisphere divided into N equal
wedges around the vertical axis, the available LATERAL (tangential)
width of one wedge at radius r from the center is:

    width(r) = 2 * r * sin(pi / N)

For N=6, sin(pi/6) = 0.5, so width(r) = r exactly -- a nice
coincidence of hexagonal geometry that makes the numbers easy to
reason about.

The other key constraint is simply RADIAL: however long your leg is
once folded/stowed, that stowed length can't exceed the sphere's
radius (minus a little room for the central hub/chassis and the
outer shell wall).
"""

import math

import matplotlib.pyplot as plt


def wedge_lateral_width(radius: float, n_wedges: int = 6) -> float:
    """Available tangential width of one wedge at a given radius from center."""
    return 2 * radius * math.sin(math.pi / n_wedges)


def analyze(L1: float, L2: float, L3: float, sphere_radius: float,
            n_wedges: int = 6, hub_radius: float = 10.0, shell_thickness: float = 5.0,
            fold_efficiencies=(1.0, 0.75, 0.6, 0.5, 0.4)):
    """
    L1, L2, L3         : your leg's link lengths (fully extended)
    sphere_radius       : target radius of the robot's folded sphere form
    n_wedges            : number of wedges the hemisphere splits into (6 for your design)
    hub_radius          : radial space reserved at the center for chassis/electronics,
                          not available for leg storage
    shell_thickness     : radial allowance near the outer surface for the shell wall
    fold_efficiencies    : range of "how well the 3 links nest when folded" to test.
                          1.0 = links folded flat end-to-end (no overlap, worst case).
                          longest_link/total = theoretical best case (links fully
                          overlap down to the length of the single longest link).
    """
    total_extended = L1 + L2 + L3
    longest_link = max(L1, L2, L3)
    best_case_efficiency = longest_link / total_extended

    available_depth = sphere_radius - hub_radius - shell_thickness

    print(f"Link lengths: L1={L1}, L2={L2}, L3={L3}  (sum = {total_extended:.1f}, longest = {longest_link:.1f})")
    print(f"Sphere radius: {sphere_radius:.1f}  -> available radial depth for stowed leg: {available_depth:.1f}")
    print(f"Theoretical best-case fold efficiency (links fully nested): {best_case_efficiency:.2f}")
    print()
    print(f"{'fold_efficiency':>16} | {'stowed_length':>14} | {'fits_radially':>13} | {'wedge_width_there':>18} | {'plausible_fit':>13}")
    print("-" * 88)

    results = []
    for eff in fold_efficiencies:
        stowed_length = eff * total_extended
        fits_radially = stowed_length <= available_depth
        width_at_stow = wedge_lateral_width(stowed_length, n_wedges)
        # crude lateral check: assume the 3 links, once folded, stack side by side
        # within the wedge's tangential width at that radius
        plausible_lateral = width_at_stow >= longest_link * 0.5  # very rough margin
        plausible = fits_radially and plausible_lateral

        results.append((eff, stowed_length, fits_radially, width_at_stow, plausible))
        print(f"{eff:>16.2f} | {stowed_length:>14.1f} | {str(fits_radially):>13} | {width_at_stow:>18.1f} | {str(plausible):>13}")

    print()
    if best_case_efficiency > 1.0:
        pass  # not possible, longest_link can't exceed total
    required_radius_for = {
        eff: eff * total_extended + hub_radius + shell_thickness for eff in fold_efficiencies
    }
    print("Sphere radius REQUIRED for each fold efficiency to just fit radially:")
    for eff, r_needed in required_radius_for.items():
        print(f"  fold_efficiency={eff:.2f}  ->  sphere radius >= {r_needed:.1f}  (diameter >= {2*r_needed:.1f})")

    return results, required_radius_for


def plot_feasibility(L1, L2, L3, sphere_radius_range, n_wedges=6, hub_radius=10.0, shell_thickness=5.0,
                      fold_efficiencies=(1.0, 0.75, 0.6, 0.5)):
    total_extended = L1 + L2 + L3

    fig, ax = plt.subplots(figsize=(8, 5))
    for eff in fold_efficiencies:
        stowed_length = eff * total_extended
        ax.axhline(stowed_length, linestyle="--", alpha=0.6,
                   label=f"stowed length @ fold_eff={eff:.2f} ({stowed_length:.0f})")

    available_depths = [r - hub_radius - shell_thickness for r in sphere_radius_range]
    ax.plot(sphere_radius_range, available_depths, color="black", linewidth=2,
            label="available radial depth (sphere_radius - hub - shell)")

    ax.set_xlabel("Sphere radius")
    ax.set_ylabel("Length")
    ax.set_title("Sphere radius needed vs. leg stowed length at various fold efficiencies\n"
                 "(feasible where the black line is ABOVE a dashed line)")
    ax.legend(fontsize=8)
    fig.tight_layout()

    import os
    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sphere_fold_feasibility.png")
    fig.savefig(out_path, dpi=150)
    print(f"\nSaved feasibility chart to {out_path}")


if __name__ == "__main__":
    # Using your current placeholder link lengths from the leg IK work
    L1, L2, L3 = 30.0, 60.0, 80.0

    print("=== Checking against a candidate sphere radius of 150 ===\n")
    analyze(L1, L2, L3, sphere_radius=150.0)

    print("\n\n=== Sweeping sphere radius to find the feasible range ===\n")
    plot_feasibility(L1, L2, L3, sphere_radius_range=list(range(80, 251, 5)))
